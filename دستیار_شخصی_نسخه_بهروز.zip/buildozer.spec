[app]
title = دستیار شخصی
package.name = personalassistant
package.domain = org.personalassistant
source.include_exts = py,png,jpg,kv,json,db
requirements = python3,kivy,plyer,pyjnius
android.permissions = READ_SMS,RECEIVE_SMS,POST_NOTIFICATIONS,FOREGROUND_SERVICE,WAKE_LOCK
orientation = portrait
