# نسخه پایه پروژه دستیار شخصی
# مرور روزانه روی ساعت 20:00 تنظیم می‌شود.
# این فایل اسکلت اولیه برای توسعه APK است.
from datetime import datetime

DAILY_REVIEW_HOUR = 20
DAILY_REVIEW_MINUTE = 0

def daily_review_questions():
    return [
        "امروز چه کارهایی انجام دادی؟",
        "امروز چه واریزی یا برداشتی داشتی؟",
        "امروز برای کدام پرسنل حقوق یا علی‌الحساب پرداخت کردی؟",
        "هزینه‌های امروز چه بوده؟",
        "برای فردا چه کارهایی داری؟",
    ]

if __name__ == "__main__":
    print("مرور روزانه:", f"{DAILY_REVIEW_HOUR:02d}:{DAILY_REVIEW_MINUTE:02d}")
    for q in daily_review_questions():
        print("-", q)
